/*
http://servicedatosabiertoscolombia.cloudapp.net/v1/Ministerio_de_Ambiente/puntosposconsumo
*/
var _departamentos = [
    {
        nombre: "Atlantico",
        ciudades: [
            {
                nombre: "Soledad"
            },
            {
                nombre: "Barranquilla"
            },
            {
                nombre: "Puerto colombia"
            }
        ]
    },
    {
        nombre: "Antioquia",
        ciudades: [
            {
                nombre: "Medellin"
            }
        ]
    },
    {
        nombre: "Amazonas"
    },
    {
        nombre: "Arauca"
    }
]


var _categorias = [
{
    nombre: "Medicamentos",
    id: "medicamentos",
    descripcion: "",
    imagen: ""
},
{
    nombre: "Pilas",
    id: "pilas",
    descripcion: "",
    imagen: ""
},
{
    nombre: "Baterías Plomo Ácido",
    id: "bupa",
    descripcion: "",
    imagen: ""
},
{
    nombre: "Llantas",
    id: "llantas",
    descripcion: "",
    imagen: ""
},
{
    nombre: "Bombillas",
    id: "bombillas",
    descripcion: "",
    imagen: ""
},
{
    nombre: "Computadores e impresoras",
    id: "computadores",
    descripcion: "",
    imagen: ""
}]