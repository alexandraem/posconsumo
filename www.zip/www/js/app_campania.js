

var ambienteApp = angular.module(
  'ambienteApp',
  ['ngRoute']
);


ambienteApp.controller( 'CampaniasCtrl', ['$scope', '$http', '$location',
    function( $scope, $http, $location ) {  
        getCampanias(function( campanias ){
            $scope.campaniaLista = campanias
            $scope.$apply()
        })

        $scope.mostrar = function(campania){
            $location.path("/" + campania.nid)
        }


    }
])
ambienteApp.controller( 'CampaniaDetalleCtrl', ['$scope', '$http', '$location', '$routeParams',
    function( $scope, $http, $location, $routeParams ) {
        getCampania( $routeParams.campaniaId , function( campain ){
            $scope.campain = campain
            $scope.campain.informacion = $scope.campain.informacion.replace('y','&'); 
            $scope.$apply()
        })

        $scope.compartir = function(){
            window.plugins.socialsharing.share('He visto la campaña '+ $scope.campain.nombre +' Visita ', null, null,  $scope.campain.informacion )
        }
    }
])


ambienteApp.config( ['$routeProvider', '$locationProvider',
  function( $routeProvider, $locationProvider ) {
    $routeProvider.
      when('/', {
        templateUrl: 'templates/campania-list.html',
        controller: 'CampaniasCtrl'
      }).
      when('/:campaniaId', {
        templateUrl: 'templates/campania-detail.html',
        controller: 'CampaniaDetalleCtrl'
      }).

      otherwise({
        redirectTo: '/'
      });

}]);





///////////////////////////////// CONSULTAS AL SET DE DATOS


function getCampania( id , success){
    $.getJSON(
        "http://servicedatosabiertoscolombia.cloudapp.net/v1/Ministerio_de_Ambiente/campanas?$filter=nid%20EQ%20+"+id+"+&$format=json",
        function(data, textStatus, jqXHR){
            var campanias = data.d
            var encontrado = false
            console.log(campanias);
            for (var i = 0; i < campanias.length; i++) {
                if ( campanias[i].nid == id ){
                    success( campanias[i] )
                    encontrado = true
                    break;
                }
            };
            if(!encontrado){
                success( {} )
                console.log("no encontrado")
            }
        })
}


function getCampanias( success ){
    $.getJSON(
        'http://servicedatosabiertoscolombia.cloudapp.net/v1/Ministerio_de_Ambiente/campanas?$format=json',
        function(data, textStatus, jqXHR){
            console.log(data);
            success(data.d)
        })
}

function CompartirFB( urlCompartir ){
    var url = urlCompartir.replace('-','&');
    console.log('https://www.facebook.com/sharer/sharer.php?u='+url+'');
    openLinkInBrowser('https://www.facebook.com/sharer/sharer.php?u='+url+'');
}